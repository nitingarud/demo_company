<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'H2n1~1]X,d~o3#/n3F#x+eSwc0q7Ld?jBA,udjF0n<_J GMniOI.x} H}wembq-t');
define('SECURE_AUTH_KEY',  'D=^44;J)D<5D>~%UGTv^1Xd*~|d%iD+APVU0B}W_(4GvNO9mm?b6+K!|xI3wGYs{');
define('LOGGED_IN_KEY',    'kr`y)SHl4h}481$T:|`b<Hd;LqB5B);7:h/46PUT-?pFSv+quVekFbnw:[WRLn9y');
define('NONCE_KEY',        '&K?nF);g^UnNw?fs+W8?;nM&3HCgslw Mk5Pcuu}OgF1R:y[]8l00p=LVIBHBv(Q');
define('AUTH_SALT',        '+},<}#&htO{HU^r&(!W,2Gqbq24J,5{@d&.R:L{LQH{5vQ8E1oj~UxDxL7@8G!i[');
define('SECURE_AUTH_SALT', 'N8zyjgjp1uT,F,<ap:]3CU:8f>NsWkK*Z6I;) qNj__6OJK7Cxs$#5]ykMk$h;V,');
define('LOGGED_IN_SALT',   'j.Xu<|2qRV_A_?op$*$9J-O{d0y`}t+Q!~[=$>-=:5^ue%PT!bA $> bvXdP@F(W');
define('NONCE_SALT',       '1OV6tdnPQ)HyH[F1#&ikECSfc.uBeva7natAkn@t:.B|dJ}OS>FO0x}hyw[<<29G');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
